import {combineReducers} from 'redux'
import courses from './courseReducer'


export const rootReducer = combineReducers({
    //courses:courses
    //OR
    courses
})
//export default rootReducer