
export default function courseReducer(state=[],action){
   switch(action.type){
       case 'CREATE_COURSE':
          // debugger
       //return state.push(action.course) //mutable , we loose the original data
       return [...state,{...action.course}]  // we are doing shallow copy with spread operator and hence
                                             // we acheive immutability by updating copy of the state[]   
       
     default:
         return state  
   }
}