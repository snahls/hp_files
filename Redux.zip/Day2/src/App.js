
import { Route,Switch } from 'react-router-dom';
import './App.css';
import AboutPage from './components/about/AboutPage';
import HomePage from './components/home/HomePage';
import Header from './components/common/Header';
import PageNotFound from './components/error/PageNotFound';
import CoursePage from './components/courses/CoursePage';

function App() {
  return (
    <div className="container">
      
        <Header/>
        <br/>
        <br/>
        <Switch>
        <Route exact path="/" component={HomePage}/>
        <Route path="/about" component={AboutPage}/>
        <Route path="/courses" component={CoursePage} />
        <Route  component={PageNotFound}/>
        </Switch>
       
      
    </div>
  );
}

export default App;
