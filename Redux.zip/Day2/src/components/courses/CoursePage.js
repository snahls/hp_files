import React,{Component} from 'react';
import { connect } from 'react-redux';
import * as  courseActions from '../../redux/actions/courseActions' 
import propTypes from 'prop-types'
//use the helper function of redux to dispatch action === bindActionCreator
import {bindActionCreators} from 'redux'
class CoursePage extends Component {
    state = { 
        course:{
            title:''
        }
     }

   handleChange=(event)=>{
    const course ={...this.state.course,title:event.target.value}
   // this.setState({course:course})  
    //OR
    this.setState({course}) // --object shorthand syntax
   }
   handleSubmit=(event)=>{
        event.preventDefault();
       // debugger;
       // this.props.dispatch(courseActions.createCourse(this.state.course))

       //OR
       //this.props.createCourse(this.state.course)
       //OR

       this.props.actions.createCourse(this.state.course)

       //alert('course added')
   }
    render() { 
        return ( 
            <div>
                <h2>  Technical Courses!!!</h2>
                <hr/>
                <form onSubmit={this.handleSubmit}>
                    <h3>Add Course</h3>
                    <input type="text" onChange={this.handleChange} 
                    value={this.state.course.title}/>
                    <input type="submit" value="Save" className="btn btn-success"/>
                    {this.props.courses.map((course,idx)=>
                        <div key={idx}>{course.title}</div>
                    )}
                </form>
            </div>
         );
    }
}
CoursePage.propTypes={
    courses:propTypes.array.isRequired,
    //dispatch:propTypes.func.isRequired
   // createCourse:propTypes.func.isRequired

   actions:propTypes.object.isRequired
    
}
 
//export default CoursePage ;

//export default connect(mapStateToProps)(CoursePage)   //connect function without mapDispatchToProps but use of distpatch props

export default connect(mapStateToProps,mapDispatchToProps)(CoursePage)
function mapStateToProps(state){
    //debugger
    return{
        courses:state.courses
    }
}
//without using bindActionCreators function of redux
// function mapDispatchToProps(dispatch){
//     return{
//         createCourse:(course)=>dispatch(courseActions.createCourse(course))
//     }

// }
function mapDispatchToProps(dispatch){
    return{
        actions:bindActionCreators(courseActions,dispatch)
    }

}