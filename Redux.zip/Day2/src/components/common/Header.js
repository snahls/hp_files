import { NavLink } from "react-router-dom"
const Header = () => {
    const style={
        color:"#f15b2a"
    }
    return ( 
        <nav>
            <NavLink to="/" exact activeStyle={style}>Home  |  </NavLink>
            <NavLink to="/about" activeStyle={style}>  About | </NavLink>
            <NavLink to="/courses" activeStyle={style}>  Courses</NavLink>

        </nav>
     );
}
 
export default Header;