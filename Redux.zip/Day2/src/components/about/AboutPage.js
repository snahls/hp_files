const AboutPage = () => {
    return (  
        <div>
            <h2>About</h2>
            <p>
                This app uses React, Redux, React Router and many other react related libraries...
            </p>
        </div>
    );
}
 
export default AboutPage;