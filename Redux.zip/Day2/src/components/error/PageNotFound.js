const PageNotFound = () => {
    return (  
        <h1>OOPs!!! Page not found!!</h1>
    );
}
 
export default PageNotFound;